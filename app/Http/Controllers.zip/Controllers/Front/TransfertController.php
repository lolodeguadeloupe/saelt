<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TransfertVoyage\TypeTransfertVoyage;
use Brackets\AdminListing\Facades\AdminListing;
use App\Models\TransfertVoyage\LieuTransfert;
use App\Models\TypePersonne;
use App\Models\Ile;
use App\Models\TransfertVoyage\TarifTransfertVoyage;
use App\Models\TransfertVoyage\TranchePersonneTransfertVoyage;

class TransfertController extends Controller
{

    public function index(Request $request)
    {

        $my_request = GestionRequestUtilisateurController::getUniqueKeyRequest($request, false);
        //
        /* filtre tranche personne*/
        $type_transfert_id = null;
        if ($request->has('customer_search') && $request->ajax() || $my_request != null) {

            $customer_search = $request->has('customer_search') ? json_decode($request->customer_search) : (object)$my_request['customer_search'];

            $personne_x = 1;
            $nb_personne = 0;
            while (isset($customer_search->{'personne_' . $personne_x})) {
                $nb_personne = $nb_personne + intval($customer_search->{'personne_' . $personne_x});
                $personne_x++;
            }
            $type_transfert_id =  TarifTransfertVoyage::select('tranche_personne_transfert_voyage.type_transfert_id')
                ->join('tranche_personne_transfert_voyage', 'tranche_personne_transfert_voyage.id', 'tarif_transfert_voyage.tranche_transfert_voyage_id')
                ->join('trajet_transfert_voyage', 'trajet_transfert_voyage.id', 'tarif_transfert_voyage.trajet_transfert_voyage_id')
                ->where([
                    'trajet_transfert_voyage.point_depart' => $customer_search->depart,
                    'trajet_transfert_voyage.point_arrive' => $customer_search->retour,
                ])
                ->where('tranche_personne_transfert_voyage.nombre_max', '>=', $nb_personne)
                ->where('tranche_personne_transfert_voyage.nombre_min', '<=', $nb_personne)->get();

            $type_transfert_id = collect($type_transfert_id)->map(function ($id_arr) {
                return $id_arr->type_transfert_id;
            })->toArray();
        }
        /* */
        // dd($type_transfert_id != null);
        $data = AdminListing::create(TypeTransfertVoyage::class)
            ->modifyQuery(function ($query) use ($request, $my_request, $type_transfert_id) {
                if ($type_transfert_id == null) {
                    $query->whereIn('id', [0]);
                } else {
                    $query->whereIn('id',  $type_transfert_id);
                }
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'titre', 'nombre_min', 'nombre_max'],
                // set columns to searchIn
                ['id', 'titre', 'description']
            );

        $collection = $data->getCollection();
        //dd($collection->toArray());
        if ($request->has('customer_search') && $request->ajax() || $my_request != null) {
            /** */
            $customer_search = $request->has('customer_search') ? json_decode($request->customer_search) : (object)$my_request['customer_search'];
            /** */
            $nb_personne = 0;

            $collection = $collection->map(function ($data, $key_collection) use ($customer_search, &$nb_personne) {
                //
                $data = collect($data);
                $personne_x = 1;
                $personne = [];
                while (isset($customer_search->{'personne_' . $personne_x})) {
                    $_personne = TypePersonne::find($personne_x);
                    $_personne['nb'] = intval($customer_search->{'personne_' . $personne_x});
                    $nb_personne = $nb_personne + intval($customer_search->{'personne_' . $personne_x});
                    $personne[] = $_personne;
                    $personne_x++;
                }
                $tarif = [
                    'aller' => 0,
                    'aller_retour' => 0,
                ];
                $data->put('all_tarif', collect($data['all_tarif'])->map(function ($data_tarif) use ($customer_search, $personne, &$tarif) {
                    //
                    $data_tarif = collect($data_tarif);
                    //
                    $id_array_pers = array_map(function ($pers) {
                        return $pers->id;
                    }, $personne);

                    if (($key = array_search($data_tarif['tarif_type_personne_id'], $id_array_pers)) !== false) {

                        $tarif = [
                            'aller' => $tarif['aller'] + (intval($data_tarif['tarif_prix_vente_aller']) * intval($personne[$key]['nb'])),
                            'aller_retour' => $tarif['aller_retour'] + (intval($data_tarif['tarif_prix_vente_aller_retour']) * intval($personne[$key]['nb'])),
                        ];
                        $data_tarif->put('nb', intval($personne[$key]['nb']));
                    } else {
                        $data_tarif->put('nb', 0);
                    }
                    return $data_tarif;
                }));
                $data->put('personne', $personne);
                $data->put('date_depart', $customer_search->date_depart);
                $data->put('date_retour', isset($customer_search->date_retour) ? $customer_search->date_retour : null);
                $data->put('heure_depart', $customer_search->heure_depart);
                $data->put('heure_retour', isset($customer_search->heure_retour) ? $customer_search->heure_retour : null);
                $data->put('parcours', $customer_search->parcours);
                $data->put('tarif', $tarif);
                $data->put('lieu_depart', LieuTransfert::find($customer_search->depart));
                $data->put('lieu_retour', LieuTransfert::find($customer_search->retour));
                $data->put('reference_prix', collect($data['all_tarif'])->min($customer_search->parcours == 2 ? 'tarif_prix_vente_aller_retour' : 'tarif_prix_vente_aller'));

                return $data;
            })->filter(function ($data) {
                return count($data['all_tarif']) > 0;
            })->values();
            $data->setCollection($nb_personne > 0 ? $collection : collect([]));
        } else {
            $data->setCollection(collect([]));
        }

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return [
                'data' => $data
            ];
        }

        /* lieu */
        $lieu_grouped = [];
        $trie = [];
        $lieu = LieuTransfert::with(['ville'])->get();
        $lieu = $lieu->map(function ($data) use (&$lieu_grouped, $trie) {

            if (($key = array_search($data->ville_id, $trie)) !== false) {
                $lieu_grouped[$key][] = $data;
            } else {
                $lieu_grouped[count($trie)][] = $data;
                $trie[] = $data->ville_id;
            }
            return $data;
        });

        //dd($data->toArray());
        return $this->viewCustom('front.transfert.transferts', [
            'data' => $data,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'aside' => [
                'lieu' => $lieu_grouped,
                'personne' => TypePersonne::whereNull('model')->whereNull('model_id')->get() 
            ]
        ]);
    }
}
