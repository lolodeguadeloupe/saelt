<?php

namespace App\Http\Controllers\Front;

use App\Exports\PayementAlma;
use App\Http\Controllers\Controller;
use App\Models\AppConfig;
use App\Models\Commande;
use App\Models\FacturationCommande;
use App\Notifications\FactureNotification;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\PDF;
use Dompdf\FontMetrics;
use Illuminate\Support\Facades\View;

class RemerciementController extends Controller
{
    public function index(Request $request)
    {
        $my_request = GestionRequestUtilisateurController::getUniqueKeyIdentifiant($request);
        /** */

        $commande = Commande::select(
            'commande.id',
            'commande.mode_payement_id',
            'commande.paiement_id',
            'commande.prix',
            'commande.tva',
            'commande.frais_dossier',
            'commande.date',
            'commande.status',
            'commande.prix_total',
            'facturation_commande.nom',
            'facturation_commande.prenom',
            'facturation_commande.adresse',
            'facturation_commande.ville',
            'facturation_commande.code_postal',
            'facturation_commande.telephone',
            'facturation_commande.email'
        )
            ->join('facturation_commande', 'facturation_commande.commande_id', 'commande.id')
            ->with([
                'facture',
                'mode_payement',
                'hebergement' => function ($query) {
                    $query->with(['personne', 'supplement', 'vol']);
                },
                'excursion' => function ($query) {
                    $query->with([
                        'personne',
                        'supplement' => function ($query) {
                            $query->with(['personne']);
                        },
                        'ile'
                    ]);
                },
                'location' => function ($query) {
                    $query->with(['personne', 'supplement']);
                },
                'billeterie' => function ($query) {
                    $query->with(['personne', 'supplement']);
                },
                'transfert' => function ($query) {
                    $query->with(['personne', 'supplement']);
                }
            ])
            ->where(['commande.paiement_id' => $my_request['paiement_id']])
            ->get();
        /** */

        if (count($commande) == 0) {
            abort(404);
        }

        $collect_first_commande = collect($commande)->first();
        $collect_first_commande = collect($collect_first_commande)->put('app', AppConfig::with(['ville'])->get()->first()->toArray());

        $facture = FacturationCommande::where(['commande_id' => $collect_first_commande['id']])
            ->get()
            ->first();

        /*return $facture_doc = $this->generatePDF([
            'data' => $collect_first_commande
        ]);*/

        if ($facture->notifications()->count() == 0) {
            $facture_doc = $this->generatePDF([
                'data' => $collect_first_commande
            ]);
            $facture->notify(new FactureNotification(['id' => $collect_first_commande['id'], 'facture' => $facture_doc, 'client' => $collect_first_commande['facture']['prenom'] . ' ' . $collect_first_commande['facture']['nom']], route('remerciement') . '?key_=' . $request->key_));
        }
        /** */
        return $this->viewCustom('front.remerciement', [
            'data' => $commande,
            'session_request' => json_encode(isset($my_request) ? $my_request : null)
        ]);
    }

    public function generatePDF($data)
    {
        //dd($data);
        $pdf = app(PDF::class)->loadView('front.pdf-facturation', $data);
        $canvas = $pdf->getDomPDF()->get_canvas();
        $w = 600; // $canvas->get_width();
        $h = 700; //$canvas->get_height();
        $font = $pdf->getDomPDF()->getFontMetrics();
        $bold = $font->get_font("helvetica", "bold");
        $regular = $font->get_font("helvetica");
        $count_page = $canvas->get_page_number( );
        $pdf->setPaper(array(0, 0, 600, 800 * $count_page), "portrait");
        $canvas->page_text(
            $w - 60,
            $h - 28,
            "Header: {PAGE_NUM} of {PAGE_COUNT}",
            $bold,
            6,
            array(0, 0, 0)
        );
        $canvas->page_text($w - 590, $h - 28, "El pie de p&aacute;gina del lado izquiero, Guadalajara, Jalisco C.P. XXXXX Tel. XX (XX) XXXX XXXX", $regular, 6);
        //return $pdf->stream();
        return $this->save_doc("Facture" . $data['data']['id'], $pdf);
    }

    private function save_doc($name, $dompdf)
    {
        $fileSystem = new \Illuminate\Filesystem\Filesystem();

        if (!$fileSystem->isDirectory(public_path('facturations'))) {
            $fileSystem->makeDirectory(public_path('facturations'));
        }
        $dompdf->save(public_path("facturations/" . $name . ".pdf"));
        return public_path("facturations/" . $name . ".pdf");
    }
}
