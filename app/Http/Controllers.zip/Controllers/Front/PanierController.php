<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Ile;
use App\Http\Controllers\Front\GestionCommandeUtilisateurController;
use App\Models\FraisDossier;
use App\Models\ModePayement;
use App\Models\Taxe;
use Carbon\Carbon;

class PanierController extends Controller {

    public function index(Request $request) {
        $my_request = GestionRequestUtilisateurController::getUniqueKeyRequest($request, false);
        //
        $commande = GestionCommandeUtilisateurController::all($request);
        //dd($commande);

        //
        $frais_dossier = FraisDossier::select('frais_dossier.*')
            ->join('saisons', 'saisons.id', 'frais_dossier.saison_id')
            ->with(['saison'])
            ->whereDate('saisons.fin', '>=', Carbon::today())
            ->get();
        //
        $frais_dossier = collect($frais_dossier)
            ->filter(function ($data) use ($frais_dossier) {
                return parse_date($data['saison']['fin']) == collect($frais_dossier)->max('saison.fin');
            })->values();
        //
        
        return $this->viewCustom('front.panier', [
            'data' => $commande,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'TVA' => Taxe::where(['titre' => 'TVA'])->get(),
            'fraisdossier' => $frais_dossier,
            'modePayement' => ModePayement::all()
        ]);
    }

}
