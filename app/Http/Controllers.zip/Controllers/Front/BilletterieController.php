<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BilleterieMaritime;
use App\Models\PlaningTime;
use Brackets\AdminListing\Facades\AdminListing;
use App\Models\Ile;
use App\Models\ServicePort;
use App\Models\TypePersonne;
use Carbon\Carbon;

class BilletterieController extends Controller
{

    public function index(Request $request)
    {
        /* implementation de filtre dans le requet my_request */
        $my_request = GestionRequestUtilisateurController::getUniqueKeyRequest($request, false);
        /* */
        $data = AdminListing::create(BilleterieMaritime::class)
            ->modifyQuery(function ($query) use ($request, $my_request) {
                $query->join('compagnie_transport', 'compagnie_transport.id', 'billeterie_maritime.compagnie_transport_id');
                $query->join('service_port as port_depart', 'port_depart.id', 'billeterie_maritime.lieu_depart_id');
                $query->join('service_port as port_arrive', 'port_arrive.id', 'billeterie_maritime.lieu_arrive_id');
                $query->with(['compagnie', 'tarif' => function ($query) use ($request) {
                    $query->with(['personne']);
                }, 'depart' => function ($query) {
                    $query->with(['ville' => function ($query) {
                        $query->with(['pays']);
                    }]);
                }, 'arrive' => function ($query) {
                    $query->with(['ville' => function ($query) {
                        $query->with(['pays']);
                    }]);
                }]);
                if ($request->has('customer_search') && $request->ajax() || $my_request != null) {

                    $customer_search = $request->has('customer_search') ? json_decode($request->customer_search) : (object)$my_request['customer_search'];

                    $query->where([
                        'port_depart.id' => $customer_search->depart,
                        'port_arrive.id' => $customer_search->arrive
                    ]);
                    if (isset($customer_search->date_depart)) {
                        $date = parse_date($customer_search->date_depart);
                        $query->where('billeterie_maritime.availability', 'like', '%' . ($date->dayOfWeek == 0 ? 6 : $date->dayOfWeek - 1) . '%');
                    }
                    if (isset($customer_search->date_retour)) {
                        $date = parse_date($customer_search->date_retour);
                        $query->where('billeterie_maritime.availability', 'like', '%' . ($date->dayOfWeek == 0 ? 6 : $date->dayOfWeek - 1) . '%');
                    }
                } else {
                    $query->where(['billeterie_maritime.id' => 0]);
                }
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'availability', 'titre', 'lieu_depart_id', 'lieu_arrive_id', 'date_depart', 'date_arrive', 'date_acquisition', 'date_limite', 'image', 'quantite', 'compagnie_transport_id'],
                // set columns to searchIn
                ['id', 'titre', 'lieu_depart', 'lieu_arrive', 'date_depart', 'date_arrive', 'date_acquisition', 'date_limite', 'quantite', 'compagnie_transport.nom', 'service_port.name', 'service_port.code_service']
            );

        $collection = $data->getCollection();

        if ($request->has('customer_search') && $request->ajax() || $my_request != null) {

            $customer_search = $request->has('customer_search') ? json_decode($request->customer_search) : (object)$my_request['customer_search'];
            //
            $personne_total = 0;
            //
            $collection = $collection->map(function ($data, $key_collection) use ($customer_search, &$personne_total) {
                //
                $data = collect($data);
                //
                $personne_x = 1;
                $personne = [];
                while (isset($customer_search->{'personne_' . $personne_x})) {
                    $_personne = TypePersonne::find($personne_x);
                    $_personne['nb'] = intval($customer_search->{'personne_' . $personne_x});
                    $personne[] = $_personne;
                    $personne_total = $personne_total + intval($customer_search->{'personne_' . $personne_x});
                    $personne_x++;
                }
                $tarif = [
                    'aller' => 0,
                    'aller_retour' => 0,
                ];

                $data->put('tarif', collect($data['tarif'])->map(function ($data_tarif) use ($customer_search, $personne, &$tarif) {
                    $data_tarif = collect($data_tarif);
                    $id_array_pers = array_map(function ($pers) {
                        return $pers->id;
                    }, $personne);

                    if (($key = array_search($data_tarif['type_personne_id'], $id_array_pers)) !== false) {

                        $tarif = [
                            'aller' => $tarif['aller'] + (intval($data_tarif['prix_vente_aller']) * intval($personne[$key]['nb'])),
                            'aller_retour' => $tarif['aller_retour'] + (intval($data_tarif['prix_vente_aller_retour']) * intval($personne[$key]['nb'])),
                        ];
                        $data_tarif->put('nb', intval($personne[$key]['nb']));
                    } else {
                        $data_tarif->put('nb', 0);
                    }

                    return $data_tarif;
                }));

                $data->put('personne', $personne);
                $data->put('date_depart', $customer_search->date_depart);
                $data->put('date_retour', isset($customer_search->date_retour) ? $customer_search->date_retour : null);
                $data->put('parcours', $customer_search->parcours);
                $data->put('tarif_calculer', $tarif);
                $data->put('reference_prix', collect($data['tarif'])->min($customer_search->parcours == 2 ? 'prix_vente_aller_retour' : 'prix_vente_aller'));
                $data->put('planing_time', PlaningTime::where(['id_model' => 'billeterie_maritime_' . $data['id']])->get());
                //
                return $data;
            })->filter(function ($data) use ($personne_total) {
                return count($data['tarif']) > 0 && count($data['planing_time']) > 0 && $data['quantite'] >= $personne_total;
            })->values();

            $data->setCollection($personne_total > 0 ? $collection : collect([]));
        } else {
            $data->setCollection(collect([]));
        }

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }

        /* port */
        $port_grouped = [];
        $trie = [];
        $port = ServicePort::with(['ville'])->get();
        $port = $port->map(function ($data) use (&$port_grouped, $trie) {

            if (($key = array_search($data->ville_id, $trie)) !== false) {
                $port_grouped[$key][] = $data;
            } else {
                $port_grouped[count($trie)][] = $data;
                $trie[] = $data->ville_id;
            }
            return $data;
        });
        return $this->viewCustom('front.billetterie-maritime.billetteries', [
            'data' => $data,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'aside' => [
                'port' => $port_grouped,
                'personne' => TypePersonne::whereNull('model')->whereNull('model_id')->get(),
            ]
        ]);
    }
}
