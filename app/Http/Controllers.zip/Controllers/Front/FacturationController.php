<?php

namespace App\Http\Controllers\Front;

use App\Exports\AlmaModele;
use App\Exports\PayementAlma;
use App\Http\Controllers\Controller;
use App\Http\Requests\PutFacturationCommande;
use App\Mail\Payement\ErrorMailPaiement;
use App\Models\ChambreEnCommande;
use App\Models\Commande;
use App\Models\Excursion\Excursion;
use App\Models\FacturationCommande;
use App\Models\FraisDossier;
use App\Models\GestionRequestUtilisateur;
use App\Models\Hebergement\Tarif;
use App\Models\Hebergement\TypeChambre;
use Illuminate\Http\Request;
use App\Models\Ile;
use App\Models\LigneCommandeBilletterie;
use App\Models\LigneCommandeChambre;
use App\Models\LigneCommandeExcursion;
use App\Models\LigneCommandeLocation;
use App\Models\LigneCommandeSupplement;
use App\Models\LigneCommandeTransfert;
use App\Models\LigneCommandeTypePersonne;
use App\Models\LigneVolHebergement;
use App\Models\ModePayement;
use App\Models\Taxe;
use App\Models\TypePersonne;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class FacturationController extends Controller
{

    public function index(Request $request)
    {
        $my_request = GestionRequestUtilisateurController::getUniqueKeyIdentifiant($request, false);
        /* */
        $commande = [];
        /* */
        if ($my_request != null) {
            $request_session = GestionRequestUtilisateur::where(['identifiant_session' => $my_request['key_']])->first();
            if ($request_session != null) {
                $request_session = $request_session->getData();
                /** */
                GestionRequestUtilisateurController::updateSessionId($request, $request_session->session_id);
                /** */
                $commande = collect($request_session->data);
            }
        } else {
            $commande = GestionCommandeUtilisateurController::all($request);
        }
        //
        $frais_dossier = FraisDossier::select('frais_dossier.*')
            ->join('saisons', 'saisons.id', 'frais_dossier.saison_id')
            ->with(['saison'])
            ->whereDate('saisons.fin', '>=', Carbon::today())
            ->get();
        //
        $frais_dossier = collect($frais_dossier)
            ->filter(function ($data) use ($frais_dossier) {
                return parse_date($data['saison']['fin']) == collect($frais_dossier)->max('saison.fin');
            })->values();
        //

        return $this->viewCustom('front.facturation', [
            'data' => $commande,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'TVA' => Taxe::where(['titre' => 'TVA'])->get(),
            'fraisdossier' => $frais_dossier,
            'modePayement' => ModePayement::all()
        ]);
    }

    public function check(Request $request)
    {
        if (!$request->has('pid'))
            abort(404);
        /** */
        $paiement = new AlmaModele();
        $payement_gateway = new PayementAlma($request, $paiement);
        $status_paiement = $payement_gateway->checkStatus($request->pid);
        if ($status_paiement['satus_code'] != 200) {
            abort(404);
        }
        $request_commande = $status_paiement['data']['orders'];
        $custom_data = json_decode($status_paiement['data']['custom_data']);
        /** */
        if (count($request_commande) == 0 && count($custom_data) == 0)
            abort(404);
        /** */

        $request_commande = $request_commande[0]->data;
        /** */
        $date = $custom_data->date;

        /** */
        if ($status_paiement['data']['state'] == "not_started" || $status_paiement['data']['state'] == "scored_no") {

            Mail::to($request_commande->client_info->email)->send(new ErrorMailPaiement([
                'url_commande' => base_url('/facturation?key_=' . $request->key_),
                'lien_titre' => "lien de commande"
            ]));

            return redirect("/facturation?key_=" . $status_paiement['data']['customer_cancel_url']);
        }
        /** */
        $commande = [
            'date' => $date,
            'status' => ($status_paiement['data']['state'] == "not_started" || $status_paiement['data']['state'] == "scored_no") ? 0 : 1, /* 0->non_payer, 1->payer, 2->annuler */
            'prix' => $custom_data->prix,
            'tva' => $custom_data->tva,
            'frais_dossier' => $custom_data->frais_dossier,
            'prix_total' => $custom_data->prix_total,
            'paiement_id' => $status_paiement['data']['id'],
            'mode_payement_id' => $custom_data->mode_payement_id
        ];
        $commande = Commande::create($commande);
        /** */
        $info_client = (array) $request_commande->client_info;
        $info_client['date'] = $date;
        $info_client['commande_id'] = $commande->id;
        /** */
        $facture = FacturationCommande::create($info_client);
        /** */
        $hebergement = $request_commande->hebergement;
        foreach ($hebergement as $key => $value) {
            $_heb = Tarif::with(
                [
                    'type_chambre' => function ($query) {
                        $query->with(['base_type']);
                    },
                    'saison',
                    'vol' => function ($query) {
                        $query->with(['allotement' => function ($query) {
                            $query->with(['compagnie', 'depart', 'arrive']);
                        }]);
                    },
                    'hebergement' => function ($query) {
                        $query->with([
                            'ile',
                            'type'
                        ]);
                    },
                    'tarif' => function ($query) {
                        $query->with(['personne']);
                    },
                    'vol' => function ($query) {
                        $query->with([
                            'allotement' => function ($query) {
                                $query->with([
                                    'compagnie' => function ($query) {
                                        $query->with(['ville']);
                                    },
                                    'depart',
                                    'arrive'
                                ]);
                            }
                        ]);
                    }
                ]
            )
                ->find($value->id);

            $_item = [
                'hebergement_id' => $_heb->hebergement->id,
                'hebergement_name' => $_heb->hebergement->name,
                'hebergement_type' => $_heb->hebergement->type->name,
                'hebergement_duration_min' => $_heb->hebergement->duration_min,
                'hebergement_caution' => $_heb->hebergement->caution,
                'hebergement_etoil' => $_heb->hebergement->etoil,
                /* */
                'chambre_id' => $_heb->type_chambre->id,
                'chambre_name' => $_heb->type_chambre->name,
                'chambre_image' => $value->image,
                'chambre_capacite' => $_heb->type_chambre->capacite,
                /* */
                'chambre_base_type_titre' => $_heb->type_chambre->base_type->titre,
                'chambre_base_type_nombre' => $_heb->type_chambre->base_type->nombre,
                /* */
                'quantite_chambre' => $value->data->chambreChecked,
                'date_debut' => parse_date(Carbon::createFromFormat('d/m/Y', $value->computed->dateDebutCalendar)),
                'date_fin' => parse_date(Carbon::createFromFormat('d/m/Y', $value->computed->dateEndCalendar)),
                /* */
                'prix_unitaire' => $value->prix,
                'prix_total' => $value->computed->prixTotal,
                'commande_id' => $commande->id,
                /* */
                'ville_id' => $_heb->hebergement->ville_id,
                'ile_id' => $_heb->hebergement->ile_id,
                'prestataire_id' => $_heb->hebergement->prestataire_id
            ];
            $_item_heb = LigneCommandeChambre::create($_item);
            $chambre = TypeChambre::find($_heb->type_chambre->id);
            ChambreEnCommande::where([
                'chambre_id' => $_heb->type_chambre->id,
                'session_id' => $request->session()->getId(),
            ])->delete();

            if ($_heb->vol) {
                $vol_heb = new LigneVolHebergement;
                $vol_heb->depart = $_heb->vol->depart;
                $vol_heb->arrive = $_heb->vol->arrive;
                $vol_heb->nombre_jour = $_heb->vol->nombre_jour;
                $vol_heb->nombre_nuit = $_heb->vol->nombre_nuit;
                $vol_heb->heure_depart = $_heb->vol->heure_depart;
                $vol_heb->heure_arrive = $_heb->vol->heure_arrive;
                /* */
                $vol_heb->allotement_id =  $_heb->vol->allotement_id;
                $vol_heb->titre = $_heb->vol->allotement->titre;
                $vol_heb->compagnie_transport_id =  $_heb->vol->allotement->compagnie_transport_id;
                $vol_heb->lieu_depart_id =  $_heb->vol->allotement->lieu_depart_id;
                $vol_heb->lieu_depart =  $_heb->vol->allotement->depart->name;
                $vol_heb->lieu_arrive_id =  $_heb->vol->allotement->lieu_arrive_id;
                $vol_heb->lieu_arrive =  $_heb->vol->allotement->arrive->name;
                //
                $vol_heb->compagnie_nom = $_heb->vol->allotement->compagnie->nom;
                $vol_heb->compagnie_email = $_heb->vol->allotement->compagnie->email;
                $vol_heb->compagnie_phone = $_heb->vol->allotement->compagnie->phone;
                $vol_heb->compagnie_adresse = $_heb->vol->allotement->compagnie->adresse;
                $vol_heb->compagnie_logo =  $_heb->vol->allotement->compagnie->logo;
                $vol_heb->type_transport =  $_heb->vol->allotement->compagnie->type_transport;
                $vol_heb->compagnie_heure_ouverture =  $_heb->vol->allotement->compagnie->heure_ouverture;
                $vol_heb->compagnie_heure_fermeture =  $_heb->vol->allotement->compagnie->heure_fermeture;
                $vol_heb->compagnie_ville_id =  $_heb->vol->allotement->compagnie->ville->id;
                $vol_heb->compagnie_ville_name =  $_heb->vol->allotement->compagnie->ville->name;
                $_item_heb->vol()->save($vol_heb);
            }

            /* type personne tarif */
            foreach ($_heb->tarif as $_personne_tarif) {
                $new_tarif_personne = new LigneCommandeTypePersonne;
                $new_tarif_personne->type = $_personne_tarif->personne->type;
                $new_tarif_personne->age = $_personne_tarif->personne->age;
                $new_tarif_personne->nb = intval($value->form->{'personne_' . $_personne_tarif->personne->id});
                $new_tarif_personne->prix_unitaire = $_personne_tarif->prix_vente;
                $new_tarif_personne->prix_total = 0;
                $_item_heb->personne()->save($new_tarif_personne);
            }

            /** supplement */
            foreach ($value->data->supplementCkecked as $key_supp => $value_supp) {
                for ($i = 0; $i < count($value_supp); $i++) {
                    $new_supp = new LigneCommandeSupplement;
                    $new_supp->titre = $value_supp[$i]->titre;
                    $new_supp->icon = $value_supp[$i]->icon;
                    $new_supp->regle_tarif = isset($value_supp[$i]->regle_tarif) ? $value_supp[$i]->regle_tarif : 1;
                    $new_supp->prix = collect($value_supp[$i]->tarif)->map(function ($data) use ($value) {
                        $personne = TypePersonne::find($data->type_personne_id);
                        return intval($value->form->{'personne_' . $personne->id}) * $data->prix_vente;
                    })->sum();
                    $_item_heb->supplement()->save($new_supp);
                    foreach ($value_supp[$i]->tarif as $value_supp_tarif) {
                        $personne = TypePersonne::find($value_supp_tarif->type_personne_id);
                        $new_supp_personne = new LigneCommandeTypePersonne;
                        $new_supp_personne->type = $personne['type'];
                        $new_supp_personne->age = $personne['age'];
                        $new_supp_personne->nb = intval($value->form->{'personne_' . $personne->id});
                        $new_supp_personne->prix_unitaire = $value_supp_tarif->prix_vente;
                        $new_supp_personne->prix_total = doubleval($value_supp_tarif->prix_vente) * intval($value->form->{'personne_' . $personne->id});
                        $new_supp->personne()->save($new_supp_personne);
                    }
                }
            }
        }
        /** */
        $excursion = $request_commande->excursion;
        foreach ($excursion as $key => $value) {
            $_exc = Excursion::with([
                'ville',
                'taxe',
                'depart',
                'arrive',
                'ile',
                'compagnie_liaison',
                'tarif' => function ($query) {
                    $query->with(['personne', 'saison']);
                },
                'supplement' => function ($query) {
                    $query->with(['tarif']);
                },
                'compagnie' => function ($query) {
                    $query->with(['ville', 'billeterie']);
                },
                'itineraire',
                'depart',
                'arrive'
            ])->find($value->id);

            $_item = [
                'excursion_id' => $_exc->id,
                'title' => $_exc->title,
                'participant_min' => $_exc->participant_min,
                'duration' => $_exc->duration,
                'fond_image' => $value->image,
                'card' => $_exc->card,
                'lunch' => $_exc->lunch,
                'ticket' => $_exc->ticket,
                'adresse_arrive' => $_exc->adresse_arrive,
                'adresse_depart' => $_exc->adresse_depart,
                'ville_id' => $_exc->ville_id,
                'ile_id' => $_exc->ile_id,
                'prestataire_id' => $_exc->prestataire_id,
                'lieu_depart_id' => $_exc->lieu_depart_id,
                'lieu_arrive_id' => $_exc->lieu_arrive_id,
                /* */
                'date_excursion' => parse_date($value->data->selectCalendarDate[0]),
                /* */
                'prix_unitaire' => $value->prix,
                'prix_total' => $value->computed->prixTotal,
                'commande_id' => $commande->id,
                /* */
            ];
            $_item_exc = LigneCommandeExcursion::create($_item);

            /* type personne tarif */
            foreach ($_exc->tarif as $_personne_tarif) {
                $new_tarif_personne = new LigneCommandeTypePersonne;
                $new_tarif_personne->type = $_personne_tarif->personne->type;
                $new_tarif_personne->age = $_personne_tarif->personne->age;
                $new_tarif_personne->nb = intval($value->form->{'personne_' . $_personne_tarif->personne->id});
                $new_tarif_personne->prix_unitaire = $_personne_tarif->prix_vente;
                $new_tarif_personne->prix_total = doubleval($_personne_tarif->prix_vente) * intval($value->form->{'personne_' . $_personne_tarif->personne->id});
                $_item_exc->personne()->save($new_tarif_personne);
            }

            /** supplement */
            foreach ($value->data->supplementCkecked as $key_supp => $value_supp) {
                for ($i = 0; $i < count($value_supp); $i++) {
                    $new_supp = new LigneCommandeSupplement;
                    $new_supp->titre = $value_supp[$i]->titre;
                    $new_supp->icon = $value_supp[$i]->icon;
                    $new_supp->regle_tarif = isset($value_supp[$i]->regle_tarif) ? $value_supp[$i]->regle_tarif : 1;
                    $new_supp->prix = collect($value_supp[$i]->tarif)->map(function ($data) use ($value) {
                        $personne = TypePersonne::find($data->type_personne_id);
                        return intval($value->form->{'personne_' . $personne->id}) * $data->prix_vente;
                    })->sum();

                    $_item_exc->supplement()->save($new_supp);

                    foreach ($value_supp[$i]->tarif as $value_supp_tarif) {
                        $personne = TypePersonne::find($value_supp_tarif->type_personne_id);
                        $new_supp_personne = new LigneCommandeTypePersonne;
                        $new_supp_personne->type = $personne['type'];
                        $new_supp_personne->age = $personne['age'];
                        $new_supp_personne->nb = intval($value->form->{'personne_' . $personne->id});
                        $new_supp_personne->prix_unitaire = $value_supp_tarif->prix_vente;
                        $new_supp_personne->prix_total = doubleval($value_supp_tarif->prix_vente) * intval($value->form->{'personne_' . $personne->id});
                        $new_supp->personne()->save($new_supp_personne);
                    }
                }
            }
        }
        /** */
        $location = $request_commande->location;
        foreach ($location as $key => $value) {

            $_item = [
                'location_id' => $value->data->item->id,
                'titre' => $value->data->item->titre,
                'immatriculation' => $value->data->item->immatriculation,
                'duration_min' => $value->data->item->duration_min,
                'image' => $value->image,
                'marque_vehicule_id' => $value->data->item->marque->id,
                'marque_vehicule_titre' => $value->data->item->marque->titre,
                'modele_vehicule_id' => $value->data->item->modele->id,
                'modele_vehicule_titre' => $value->data->item->modele->titre,
                'categorie_vehicule_id' => $value->data->item->categorie->id,
                'categorie_vehicule_titre' => $value->data->item->categorie->titre,
                'famille_vehicule_id' => $value->data->item->categorie->famille->id,
                'famille_vehicule_titre' => $value->data->item->categorie->famille->titre,
                'prestataire_id' => $value->data->item->prestataire_id,
                'agence_recuperation_name' => $value->data->item->agence_recuperation->name,
                'agence_recuperation_id' => $value->data->item->agence_recuperation->id,
                'agence_restriction_name' => $value->data->item->agence_restriction->name,
                'agence_restriction_id' => $value->data->item->agence_restriction->id,
                'date_recuperation' => parse_date(Carbon::createFromFormat('Y-m-d', $value->form->date_recuperation)),
                'date_restriction' => parse_date(Carbon::createFromFormat('Y-m-d', $value->form->date_restriction)),
                'heure_recuperation' => $value->form->heure_recuperation,
                'heure_restriction' => $value->form->heure_restriction,
                'nom_conducteur' => $value->form->nom,
                'prenom_conducteur' => $value->form->prenom,
                'adresse_conducteur' => $value->form->adresse,
                'ville_conducteur' => $value->form->ville,
                'code_postal_conducteur' => $value->form->{'code-postal'},
                'telephone_conducteur' => $value->form->telephone,
                'email_conducteur' => $value->form->email,
                'date_naissance_conducteur' => $value->form->{'date-naissance'},
                'lieu_naissance_conducteur' => $value->form->{'lieu-naissance'},
                'num_permis_conducteur' => $value->form->{'num-permis'},
                'date_permis_conducteur' => $value->form->{'date-permis'},
                'lieu_deliv_permis_conducteur' => $value->form->{'lieu-deliv-permis'},
                'num_identite_conducteur' => $value->form->{'num-identite'},
                'date_emis_identite_conducteur' => $value->form->{'date-emis-identite'},
                'lieu_deliv_identite_conducteur' => $value->form->{'lieu-deliv-identite'},
                'order_comments' => $value->form->order_comments,
                /* */
                'prix_unitaire' => $value->prix,
                'prix_total' => $value->computed->prixTotal,
                'commande_id' => $commande->id
                /* */
            ];

            foreach ($value->data->assurance as $val) {
                $_item[$val->assurance] = $val->value;
            }

            $_item_location = LigneCommandeLocation::create($_item);
            /* supplement */


            if ($value->data->item->categorie->supplement != null) {
                $new_supp = new LigneCommandeSupplement;
                $new_supp->titre = $value->data->item->categorie->supplement->trajet->titre;
                $new_supp->regle_tarif =  1;
                $new_supp->prix = $value->data->item->categorie->supplement->tarif;
                $_item_location->supplement()->save($new_supp);
            }
        }
        /** */
        $billeterie = $request_commande->billeterie;

        foreach ($billeterie as $key => $value) {

            $_item = [
                'titre' => $value->data->item->titre,
                'date_depart' => parse_date(Carbon::createFromFormat('Y-m-d', $value->data->item->date_depart)),
                'image' => $value->image,
                'quantite' => collect($value->data->item->personne)->map(function ($data) {
                    return $data->nb;
                })->sum(),
                'compagnie_transport_id' => $value->data->item->compagnie->id,
                'compagnie_transport_name' => $value->data->item->compagnie->nom,
                'lieu_depart_id' => $value->data->item->depart->id,
                'lieu_depart_name' => $value->data->item->depart->name,
                'lieu_arrive_id' => $value->data->item->arrive->id,
                'lieu_arrive_name' => $value->data->item->arrive->name,
                /* */
                'parcours' => $value->data->item->parcours,
                'heure_aller' => $value->form->heure_aller,
                /* */
                'prix_unitaire' => $value->prix,
                'prix_total' => $value->computed->prixTotal,
                'commande_id' => $commande->id,
            ];
            if ($value->data->item->parcours == 2) {
                $_item['date_retour'] = parse_date(Carbon::createFromFormat('Y-m-d', $value->data->item->date_retour));
                $_item['heure_retour'] = $value->form->heure_retour;
            }
            $_item_billet = LigneCommandeBilletterie::create($_item);

            /* type personne tarif */
            foreach ($value->data->item->tarif as $_personne_tarif) {
                $new_tarif_personne = new LigneCommandeTypePersonne;
                $new_tarif_personne->type = $_personne_tarif->personne->type;
                $new_tarif_personne->age = $_personne_tarif->personne->age;
                $new_tarif_personne->nb = $_personne_tarif->nb;
                $new_tarif_personne->prix_unitaire = $value->data->item->parcours == 1 ? $_personne_tarif->prix_vente_aller : $_personne_tarif->prix_vente_aller_retour;
                $new_tarif_personne->prix_total = $value->data->item->parcours == 1 ? doubleval($_personne_tarif->prix_vente_aller) * intval($_personne_tarif->nb) : doubleval($_personne_tarif->prix_vente_aller_retour) * intval($_personne_tarif->nb);
                $_item_billet->personne()->save($new_tarif_personne);
            }
        }
        /** */
        $transfert = $request_commande->transfert;
        foreach ($transfert as $key => $value) {

            $_item = [
                'titre' => $value->data->item->titre,
                'date_depart' => parse_date(Carbon::createFromFormat('Y-m-d', $value->data->item->date_depart)),
                'image' => $value->image,
                'quantite' => collect($value->data->item->personne)->map(function ($data) {
                    return $data->nb;
                })->sum(),
                'lieu_depart_id' => $value->data->item->lieu_depart->id,
                'lieu_depart_name' => $value->data->item->lieu_depart->titre,
                'lieu_arrive_id' => $value->data->item->lieu_retour->id,
                'lieu_arrive_name' => $value->data->item->lieu_retour->titre,
                /* */
                'parcours' => $value->data->item->parcours,
                'heure_depart' => $value->data->item->heure_depart,
                /* */
                'prix_unitaire' => $value->prix,
                'prix_total' => $value->computed->prixTotal,
                'commande_id' => $commande->id,
            ];
            if ($value->data->item->parcours == 2) {
                $_item['date_retour'] = parse_date(Carbon::createFromFormat('Y-m-d', $value->data->item->date_retour));
                $_item['heure_retour'] = $value->data->item->heure_retour;
            }
            $_item_trans = LigneCommandeTransfert::create($_item);

            /* type personne tarif */
            foreach ($value->data->item->all_tarif as $_personne_tarif) {
                $new_tarif_personne = new LigneCommandeTypePersonne;
                $new_tarif_personne->type = $_personne_tarif->personne_type;
                $new_tarif_personne->age = $_personne_tarif->personne_age;
                $new_tarif_personne->nb = $_personne_tarif->nb;
                $new_tarif_personne->prix_unitaire = $value->data->item->parcours == 1 ? $_personne_tarif->tarif_prix_vente_aller : $_personne_tarif->tarif_prix_vente_aller_retour;
                $new_tarif_personne->prix_total = $value->data->item->parcours == 1 ? doubleval($_personne_tarif->tarif_prix_vente_aller) * intval($_personne_tarif->nb) : doubleval($_personne_tarif->tarif_prix_vente_aller_retour) * intval($_personne_tarif->nb);
                $_item_trans->personne()->save($new_tarif_personne);
            }
        }

        /** delete commande */
        GestionCommandeUtilisateurController::delete_all($request);
        /** delete commande */
        $key_session =  GestionRequestUtilisateurController::putIdentifiantKey([
            'paiement_id' => $status_paiement['data']['id']
        ]);
        return  redirect('remerciement?key_=' . $key_session['key']);
    }

    public function paiement(PutFacturationCommande $request)
    {
        /* */
        $key_session =  GestionRequestUtilisateurController::putIdentifiantKey([
            'key_' => GestionCommandeUtilisateurController::identifiantSession($request)
        ]);
        /* */

        $date = parse_date(now());
        $commande = [
            'date' => $date,
            'status' => 0, /* 0->non_payer, 1->payer, 2->annuler */
            'prix' => doubleval($request->tarifTotal),
            'tva' => doubleval($request->taxe_tva),
            'frais_dossier' => doubleval($request->frais_dossier),
            'prix_total' => doubleval($request->tarifTotalTaxe),
            'mode_payement_id' => $request->mode_payement,
            'identifiant_session' => $key_session['key']
        ];
        $info_client = $request->client_info;

        /** */
        $paiement = new AlmaModele();
        $paiement->payment_purchase_amount = doubleval($commande['prix_total']) * 100;
        $paiement->payment_installments_count = 1;
        $paiement->payment_return_url = base_url('/check-facturation?key_=' . $commande['identifiant_session']);
        $paiement->payment_shipping_address_first_name = $info_client['nom'];
        $paiement->payment_shipping_address_last_name = $info_client['prenom'];
        $paiement->payment_shipping_address_line1 = $info_client['adresse'];
        $paiement->payment_shipping_address_postal_code = $info_client['code_postal'];
        $paiement->payment_shipping_address_city = $info_client['ville'];
        $paiement->payment_locale = 'fr';
        $paiement->payment_origin = 'online';
        /** */
        $paiement->customer_first_name = 'SAELT VOYAGES';
        $paiement->customer_last_name = 'Saelt voyages';
        /** */
        $paiement->customer_fee = 0; // frais payé par le client appart montant
        $paiement->customer_interest = 0; // intéret payé par le client appart montant
        $paiement->payment_ipn_callback_url = base_url('/check-payement'); // url de sécoure
        $paiement->payment_merchant_name = 'Sael voyages'; // nom de marchand ayant créé le paiement,
        $paiement->payment_custom_data = collect($commande)->toJson(); //Objet JSON de format libre qui vous permet d'associer au paiement Alma des données provenant de votre base de données.
        /** */
        $paiement->orders_merchant_reference = '' . $commande['identifiant_session'] . '';
        $paiement->orders_merchant_url = base_url('/panier?key_=' . $commande['identifiant_session']);
        $paiement->orders_data =   $request->all();
        /** */
        $paiement->customer_cancel_url = base_url('/facturation?key_=' . $commande['identifiant_session']);

        /** */
        $payement_gateway = new PayementAlma($request, $paiement);
        $payement_info = $payement_gateway->payer();

        if ($payement_info['satus_code'] == 200) {
            return response($payement_info['data']['url'], $payement_info['satus_code'])
                ->header('Content-Type', 'text/json');
        } else {
            return response($payement_info['data'], $payement_info['satus_code'])
                ->header('Content-Type', 'text/json');
        }
    }
}
