<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Ile;
use App\Models\LocationVehicule\AgenceLocation;
use App\Models\ServicePort;
use App\Models\TransfertVoyage\LieuTransfert;
use Brackets\AdminListing\AdminListing;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $my_request = GestionRequestUtilisateurController::getUniqueKeyRequest($request, false);
        //
        $data = AdminListing::create(Ile::class)
            ->modifyQuery(function ($query) use ($request) {
                $query->with(['hebergement']);
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'name', 'card', 'pays_id', 'background_image'],
                // set columns to searchIn
                ['id', 'name', 'card', 'pays_id', 'background_image']
            );

        $collection = $data->getCollection();
        $collection = $data->filter(function ($data) {
            return count($data->hebergement);
        });
        $data->setCollection($collection);

        /* port */
        $port_grouped = [];
        $trie = [];
        $port = ServicePort::with(['ville'])->get();
        $port = $port->map(function ($data) use (&$port_grouped, $trie) {

            if (($key = array_search($data->ville_id, $trie)) !== false) {
                $port_grouped[$key][] = $data;
            } else {
                $port_grouped[count($trie)][] = $data;
                $trie[] = $data->ville_id;
            }
            return $data;
        });
        /* lieu */
        $lieu_grouped = [];
        $trie = [];
        $lieu = LieuTransfert::with(['ville'])->get();
        $lieu = $lieu->map(function ($data) use (&$lieu_grouped, $trie) {

            if (($key = array_search($data->ville_id, $trie)) !== false) {
                $lieu_grouped[$key][] = $data;
            } else {
                $lieu_grouped[count($trie)][] = $data;
                $trie[] = $data->ville_id;
            }
            return $data;
        });

        return $this->viewCustom('front.home', [
            'data' => $data,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'aside' => [
                'port' => $port_grouped,
                'lieu' => $lieu_grouped,
                'agence_location' => AgenceLocation::all()
            ]
        ]);
    }
}
