<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Excursion\Excursion;
use App\Models\Excursion\TarifExcursion;
use Brackets\AdminListing\Facades\AdminListing;
use App\Models\Ville;
use App\Models\Ile;
use App\Models\LocationVehicule\AgenceLocation;
use App\Models\TypePersonne;
use Illuminate\Support\Facades\DB;

class ExcursionController extends Controller
{

    public function index(Request $request)
    {

        $data = AdminListing::create(Ile::class)
            ->modifyQuery(function ($query) use ($request) {
                $query->with(['excursion']);
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'name', 'card', 'pays_id', 'background_image'],
                // set columns to searchIn
                ['id', 'name', 'card', 'pays_id', 'background_image']
            );

        $collection = $data->getCollection();
        $collection = $data->filter(function ($data) {
            return count($data->excursion);
        })->values();
        $data->setCollection($collection);

        return $this->viewCustom('front.excursion.excursions', [
            'data' => $data,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
        ]);
    }

    public function allproducts(Request $request)
    {

        /* search */
        $excursion_filter_id = null;
        $filter_ile = null;

        /* search ajax */
        if ($request->has('customer_search') && $request->ajax()) {
            $customer_search = json_decode($request->customer_search);
            $ile_id = explode(',', $customer_search->ile);
            $columns_search = [
                'iles.name',
                'villes.name',
                'lieu_depart.name',
                'lieu_arrive.name',
                'excursions.title',
                'excursions.heure_depart',
                'excursions.description',
                'excursions.adresse_depart',
                'excursions.adresse_arrive',
            ];

            /* affectation valeur filter */
            $mot_cle = isset($customer_search->mot_cle) ? $customer_search->mot_cle : '';
            $price = explode(',', $customer_search->price);

            /* indication ile filter */
            if (count($ile_id) > 1) {
                $filter_ile = trans('admin-base.filter.all_ile');
            } else {
                $filter_ile = Ile::find($ile_id[0])->name;
            }

            /* globale filter dans la base de données */
            $excursion_filter = Excursion::select('excursions.id')
                ->join('iles', 'iles.id', 'excursions.ile_id')
                ->join('villes', 'villes.id', 'excursions.ville_id')
                ->leftJoin('service_port as lieu_depart', 'lieu_depart.id', 'excursions.lieu_depart_id')
                ->leftJoin('service_port as lieu_arrive', 'lieu_arrive.id', 'excursions.lieu_arrive_id')
                ->join('tarif_excursion', 'tarif_excursion.excursion_id', 'excursions.id')
                ->whereIn('iles.id', $ile_id)
                ->where(function ($query) use ($columns_search, $mot_cle) {
                    array_map(function ($array) use (&$query, $mot_cle) {
                        $query = $query->orWhere(DB::raw('lower(' . $array . ')'), 'like', '%' . strtolower($mot_cle) . '%');
                    }, $columns_search);
                })
                ->whereBetween('tarif_excursion.prix_vente', $price);

            if ($customer_search->duration != '*') {
                $excursion_filter = $excursion_filter->where(['excursions.duration' => $customer_search->duration]);
            }

            $excursion_filter = $excursion_filter->get();

            /* liste hebergement_id trouvée par la filtre */
            $excursion_filter_id = $excursion_filter->map(function ($data_collection) {
                return $data_collection->id;
            })->values();

            /* search interactif get */
        } else {
            /* filter ile seulement si le customer_filter no definie */
            $my_request = GestionRequestUtilisateurController::getUniqueKeyRequest($request, false);

            if ($my_request != null) {
                $iles_id = explode(',', $my_request['ile']);
                $filter_ile = count($iles_id) == 1 ? Ile::find($iles_id[0])->name : 'Tout';

                $excursion_filter = Excursion::select('excursions.*')
                    ->join('tarif_excursion', 'tarif_excursion.excursion_id', 'excursions.id')
                    ->join('saisons', 'saisons.id', 'tarif_excursion.saison_id')
                    ->whereIn('ile_id', $iles_id);

                /* villes */
                if (isset($my_request['ville'])) {
                    $excursion_filter = $excursion_filter->whereIn('ville_id', explode(',', $my_request['ville']));
                }

                /* saison debut */
                if (isset($my_request['date_debut'])) {
                    $excursion_filter = $excursion_filter->whereDate('saisons.debut', '<=', $my_request['date_debut']);
                }

                /* saison fin */
                if (isset($my_request['date_fin'])) {
                    $excursion_filter = $excursion_filter->whereDate('saisons.fin', '>=', $my_request['date_fin']);
                }

                $excursion_filter = $excursion_filter->get();

                $excursion_filter_id = $excursion_filter->map(function ($data_collection) {
                    return $data_collection->id;
                })->values();
            } else {
                $excursion_filter = Excursion::first();
                if ($excursion_filter) {
                    $excursion_filter_id = [$excursion_filter->id];
                }
                $filter_ile = Ile::find($excursion_filter->ile_id)->name;
            }
        }

        if (count($excursion_filter_id) == 0) {
            $excursion_filter_id = [0];
        }
        /* search */
        $data = AdminListing::create(Excursion::class)
            ->modifyQuery(function ($query) use ($request, $excursion_filter_id) {
                $query->join('iles', 'iles.id', 'excursions.ile_id');
                $query->join('villes', 'villes.id', 'excursions.ville_id');
                $query->leftJoin('service_port as lieu_depart', 'lieu_depart.id', 'excursions.lieu_depart_id');
                $query->leftJoin('service_port as lieu_arrive', 'lieu_arrive.id', 'excursions.lieu_arrive_id');
                $query->with(['ville', 'taxe', 'depart', 'arrive', 'ile', 'compagnie_liaison', 'tarif' => function ($query) {
                    $query->with(['personne']);
                }, 'supplement' => function ($query) {
                    $query->with(['tarif']);
                }, 'compagnie' => function ($query) {
                    $query->with(['ville', 'billeterie']);
                }]);
                $query->whereIn('excursions.id', $excursion_filter_id);
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'title', 'lunch', 'ticket', 'availability', 'participant_min', 'card', 'heure_depart', 'description', 'ville_id', 'prestataire_id', 'status', 'duration', 'lieu_depart_id', 'lieu_arrive_id', 'ile_id', 'adresse_depart', 'adresse_arrive'],
                // set columns to searchIn
                ['id', 'title', 'lunch', 'ticket', 'availability', 'participant_min', 'card', 'heure_depart', 'prestataire.name', 'lieu_depart.name', 'lieu_arrive.name', 'iles.name', 'adresse_depart', 'adresse_arrive']
            );
        $collection = $data->getCollection();
        $collection = $collection->map(function ($data) {
            $data = collect($data);
            $data->put('supplement', collect($data['supplement'])->groupBy('type_label.value'));
            $data->put('tarif', collect($data['tarif'])->filter(function ($tarif) use ($data) {
                $has_adulte = collect($data['tarif'])->filter(function ($personne) {
                    return strtolower($personne['personne']['id']) == "1";
                })->values();
                if (count($has_adulte)) {
                    return $tarif['type_personne_id'] == $has_adulte[0]['type_personne_id']; // check personne adulte
                } else {
                    return $tarif['prix_vente'] == collect($data['tarif'])->min('prix_vente'); //reference prix
                }
            })->values());

            if (count($data['tarif'])) {
                $data->put('tarif', collect($data['tarif'])->first()); //set tarif to object
            } else {
                $data->put('tarif', null); //set tarif to object
            }
            return $data;
        })->values();

        $collection = $collection->filter(function ($data) {
            return $data['tarif'] != null;
        })->values();

        $data->setCollection($collection);

        //dd($data->toArray());
        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }
        return $this->viewCustom('front.excursion.excursion-all-products', [
            'data' => $data,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'filter_ile' => $filter_ile
        ]);
    }

    public function product(Request $request)
    {

        $my_request = GestionRequestUtilisateurController::getUniqueKeyRequest($request);
        //
        $data = AdminListing::create(Excursion::class)
            ->modifyQuery(function ($query) use ($request, $my_request) {
                $query->join('iles', 'iles.id', 'excursions.ile_id');
                $query->join('villes', 'villes.id', 'excursions.ville_id');
                $query->leftJoin('service_port as lieu_depart', 'lieu_depart.id', 'excursions.lieu_depart_id');
                $query->leftJoin('service_port as lieu_arrive', 'lieu_arrive.id', 'excursions.lieu_arrive_id');
                $query->with(['ville', 'taxe', 'depart', 'arrive', 'ile', 'compagnie_liaison', 'tarif' => function ($query) {
                    $query->with(['personne', 'saison']);
                }, 'supplement' => function ($query) {
                    $query->with(['tarif']);
                }, 'compagnie' => function ($query) {
                    $query->with(['ville', 'billeterie']);
                }, 'itineraire', 'depart', 'arrive']);
                $query->where(['excursions.id' => $my_request['id']]);
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'title', 'lunch', 'ticket', 'availability', 'participant_min', 'card', 'heure_depart', 'description', 'ville_id', 'prestataire_id', 'status', 'duration', 'lieu_depart_id', 'lieu_arrive_id', 'ile_id', 'adresse_depart', 'adresse_arrive', 'fond_image'],
                // set columns to searchIn
                ['id', 'title', 'lunch', 'ticket', 'availability', 'participant_min', 'card', 'heure_depart', 'prestataire.name', 'lieu_depart.name', 'lieu_arrive.name', 'iles.name', 'adresse_depart', 'adresse_arrive']
            );
        $collection = $data->getCollection();
        $collection = $collection->map(function ($data) {
            $data = collect($data);
            $saison = null;
            $data->put('supplement', collect($data['supplement'])->groupBy('type_label.value'));
            $data->put('reference_tarif', collect($data['tarif'])->filter(function ($tarif) use ($data, &$saison) {
                $saison = collect($tarif)->get('saison');
                $has_adulte = collect($data['tarif'])->filter(function ($personne) {
                    return strtolower($personne['personne']['id']) == "1";
                })->values();
                if (count($has_adulte)) {
                    return $tarif['type_personne_id'] == $has_adulte[0]['type_personne_id']; // check personne adulte
                } else {
                    return $tarif['prix_vente'] == collect($data['tarif'])->min('prix_vente'); //reference prix
                }
            })->values());
            if (count($data['reference_tarif'])) {
                $reference_tarif = collect($data['reference_tarif']);
                $reference_tarif = $reference_tarif->filter(function ($data) use ($reference_tarif) {
                    return $data['prix_vente'] == $reference_tarif->min('prix_vente');
                });
                $data->put('reference_tarif', $reference_tarif->first()); //set tarif to object
            } else {
                $data->put('reference_tarif', null); //set tarif to object
            }
            $data->put('saison', $saison);
            /* has location */
            $data->put('agence_location', AgenceLocation::where(['ville_id' => $data->get('ville_id')])->get());

            /**  */
            $tarif = collect($data['tarif'])->groupBy('saison.id', false);
            $data->put('tarif', collect($tarif)->first());
            return $data;
        })->values();

        $data->setCollection($collection);
        //dd($data->toArray());
        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }
        //dd($data->toArray());
        return $this->viewCustom('front.excursion.excursion-product', [
            'data' => $data,
            'session_request' => json_encode(isset($my_request) ? $my_request : null),
            'personne' => Excursion::find($my_request['id'])->personne()->get(),
            'commande_saved' => GestionCommandeUtilisateurController::modifier($request, 'excursion', $my_request['id'], collect($my_request)->get('date_commande')),
            'edit_pannier' => isset($my_request['panier']) && $my_request['panier'] == true,
        ]);
    }

    public function productPrice(Request $request)
    {
        $saison = $request->saison;
        $tarif_saison = collect($saison)->map(function ($data) use ($request) {
            $tarifs = TarifExcursion::select('tarif_excursion.*')
                ->with(['saison'])
                ->join('saisons', 'saisons.id', 'tarif_excursion.saison_id')
                ->where(['excursion_id' => $request->excursion_id])
                ->whereDate('saisons.debut', '<=', parse_date($data))
                ->whereDate('saisons.fin', '>=', parse_date($data))
                ->get();
            /** */
            $_saison_max = collect($tarifs)->max('saison.fin');
            /** */
            $tarifs = collect($tarifs)->groupBy('saison.id', false)->values();
            /** */
            $_tarif_max_saison = collect($tarifs)->filter(function ($data) use ($_saison_max) {
                return parse_date(collect($data)->first()->saison->fin) == $_saison_max;
            })->first();
            /** */
            return $_tarif_max_saison;
        });
        /** seconde traitement */
        $_tarif_max_saison = [];
        collect($tarif_saison)->map(function ($data, $index) use (&$_tarif_max_saison, $tarif_saison) {
            if ($index == 0) {
                $_tarif_max_saison = $data;
            } else {
                collect($_tarif_max_saison)->map(function ($_data_personne) use ($data, $tarif_saison) {
                    /** */
                    $_data_personne->prix_vente = (doubleval($_data_personne->prix_vente) + doubleval(collect($data)->filter(function ($_fitre_data) use ($_data_personne) {
                        return $_data_personne->type_personne_id == $_fitre_data->type_personne_id;
                    })->first()->prix_vente));
                    /** */
                    $_data_personne->prix_achat = (doubleval($_data_personne->prix_achat) + doubleval(collect($data)->filter(function ($_fitre_data) use ($_data_personne) {
                        return $_data_personne->type_personne_id == $_fitre_data->type_personne_id;
                    })->first()->prix_achat));
                    /** */
                    $_data_personne->marge = (doubleval($_data_personne->marge) + doubleval(collect($data)->filter(function ($_fitre_data) use ($_data_personne) {
                        return $_data_personne->type_personne_id == $_fitre_data->type_personne_id;
                    })->first()->marge));
                    /** */
                });
            }
        });

        collect($_tarif_max_saison)->map(function ($_data_personne) use ($tarif_saison) {
            /** */
            $_data_personne->prix_vente = doubleval($_data_personne->prix_vente) / count($tarif_saison);
            /** */
            $_data_personne->prix_achat = doubleval($_data_personne->prix_achat) / count($tarif_saison);
            /** */
            $_data_personne->marge = doubleval($_data_personne->marge) / count($tarif_saison);
            /** */
        });
        /** */
        return [
            'tarif' => $_tarif_max_saison
        ];
    }
}
