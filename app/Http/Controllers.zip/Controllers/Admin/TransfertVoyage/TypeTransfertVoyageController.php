<?php

namespace App\Http\Controllers\Admin\TransfertVoyage;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TransfertVoyage\TypeTransfertVoyage\BulkDestroyTypeTransfertVoyage;
use App\Http\Requests\Admin\TransfertVoyage\TypeTransfertVoyage\DestroyTypeTransfertVoyage;
use App\Http\Requests\Admin\TransfertVoyage\TypeTransfertVoyage\IndexTypeTransfertVoyage;
use App\Http\Requests\Admin\TransfertVoyage\TypeTransfertVoyage\StoreTypeTransfertVoyage;
use App\Http\Requests\Admin\TransfertVoyage\TypeTransfertVoyage\UpdateTypeTransfertVoyage;
use App\Http\Requests\Admin\TransfertVoyage\TypeTransfertVoyage\AutocompletionTypeTransfertVoyage;
use App\Models\TransfertVoyage\TypeTransfertVoyage;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class TypeTransfertVoyageController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @param IndexTypeTransfertVoyage $request
     * @return array|Factory|View
     */
    public function index(IndexTypeTransfertVoyage $request) {
        // create and AdminListing instance for a specific model and
        $data = AdminListing::create(TypeTransfertVoyage::class)
                ->modifyQuery(function($query) use ($request) {
                    
                })
                ->processRequestAndGet(
                // pass the request with params
                $request,
                // set columns to query
                ['id', 'titre', 'nombre_min', 'nombre_max'],
                // set columns to searchIn
                ['id', 'titre', 'description']
        );

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }

        return view('admin.transfert-voyage.type-transfert-voyage.index', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create() {
        $this->authorize('admin.type-transfert-voyage.create');

        if (!$this->request->ajax()) {
            abort(404);
        }

        return [];
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreTypeTransfertVoyage $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreTypeTransfertVoyage $request) {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the TypeTransfertVoyage
        $typeTransfertVoyage = TypeTransfertVoyage::create($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/type-transfert-voyages'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
                'typeTransfertVoyage' => $typeTransfertVoyage,
            ];
        }

        return redirect('admin/type-transfert-voyages');
    }

    /**
     * Display the specified resource.
     *
     * @param TypeTransfertVoyage $typeTransfertVoyage
     * @throws AuthorizationException
     * @return void
     */
    public function show(TypeTransfertVoyage $typeTransfertVoyage) {
        $this->authorize('admin.type-transfert-voyage.show', $typeTransfertVoyage);

        if (!$this->request->ajax()) {
            abort(404);
        }
        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param TypeTransfertVoyage $typeTransfertVoyage
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(TypeTransfertVoyage $typeTransfertVoyage) {
        $this->authorize('admin.type-transfert-voyage.edit', $typeTransfertVoyage);

        if (!$this->request->ajax()) {
            abort(404);
        }

        return [
            'typeTransfertVoyage' => $typeTransfertVoyage,
        ];
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateTypeTransfertVoyage $request
     * @param TypeTransfertVoyage $typeTransfertVoyage
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateTypeTransfertVoyage $request, TypeTransfertVoyage $typeTransfertVoyage) {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values TypeTransfertVoyage
        $typeTransfertVoyage->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/type-transfert-voyages'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
                'typeTransfertVoyage' => $typeTransfertVoyage,
            ];
        }

        return redirect('admin/type-transfert-voyages');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroyTypeTransfertVoyage $request
     * @param TypeTransfertVoyage $typeTransfertVoyage
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroyTypeTransfertVoyage $request, TypeTransfertVoyage $typeTransfertVoyage) {
        $typeTransfertVoyage->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroyTypeTransfertVoyage $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroyTypeTransfertVoyage $request): Response {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                    ->chunk(1000)
                    ->each(static function ($bulkChunk) {
                        TypeTransfertVoyage::whereIn('id', $bulkChunk)->delete();

                        // TODO your code goes here
                    });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }

    public function autocompletion(AutocompletionTypeTransfertVoyage $resquest) {
        $sanitized = $resquest->getSanitized();
        $search = TypeTransfertVoyage::with(['tranche'])
                ->where(function($query) use($sanitized) {
                    $query->where('titre', 'like', '%' . $sanitized['search'] . '%');
                })
                ->limit(20)
                ->get();

        if (!$this->request->ajax()) {
            abort(404);
        }

        return [
            'search' => $search,
        ];
    }

}
