<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\FraisDossier\BulkDestroyFraisDossier;
use App\Http\Requests\Admin\FraisDossier\DestroyFraisDossier;
use App\Http\Requests\Admin\FraisDossier\IndexFraisDossier;
use App\Http\Requests\Admin\FraisDossier\StoreFraisDossier;
use App\Http\Requests\Admin\FraisDossier\UpdateFraisDossier;
use App\Models\FraisDossier;
use App\Models\Saison;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class FraisDossierController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexFraisDossier $request
     * @return array|Factory|View
     */
    public function index(IndexFraisDossier $request)
    {
        // create and AdminListing instance for a specific model and
        $data = AdminListing::create(FraisDossier::class)
            ->modifyQuery(function ($query) use ($request) {
                $query->join('saisons', 'saisons.id', 'frais_dossier.saison_id');
                $query->with(['saison']);
            })
            ->processRequestAndGet(
                // pass the request with params
                $request,

                // set columns to query
                ['id', 'saison_id', 'prix'],

                // set columns to searchIn
                ['id', 'saisons.titre', 'saisons.debut', 'saisons.fin']
            );

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }

        return view('admin.frais-dossier.index', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create(Request $request)
    {
        if (!$request->ajax()) {
            abort(404);
        }
        $this->authorize('admin.frais-dossier.create');

        return [];
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreFraisDossier $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreFraisDossier $request)
    {
        /* 
        
        */
        // Sanitize input
        $sanitized = $request->getSanitized();

        DB::transaction(static function () use ($sanitized) {
            $saison = [
                'titre' => trans('admin.frais-dossier.title') . ' ' . parse_date($sanitized['debut'])->format('d-m-Y') . ' - ' . parse_date($sanitized['fin'])->format('d-m-Y'),
                'debut' => $sanitized['debut'],
                'fin' => $sanitized['fin'],
                'model_saison' => 'frais_dossier'
            ];
            $saison = Saison::create($saison);
            // Store the FraisDossier
            $fraisDossier = FraisDossier::create([
                'saison_id' => $saison->id,
                'prix' => $sanitized['prix'],
            ]);
        });

        if ($request->ajax()) {
            return ['redirect' => url('admin/frais-dossiers'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/frais-dossiers');
    }

    /**
     * Display the specified resource.
     *
     * @param FraisDossier $fraisDossier
     * @throws AuthorizationException
     * @return void
     */
    public function show(Request $request, FraisDossier $fraisDossier)
    {
        if (!$request->ajax()) {
            abort(404);
        }
        $this->authorize('admin.frais-dossier.show', $fraisDossier);

        // TODO your code goes here
        return ['fraisDossier' => FraisDossier::with(['saison'])->find($fraisDossier->id),];
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param FraisDossier $fraisDossier
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(Request $request, FraisDossier $fraisDossier)
    {
        if (!$request->ajax()) {
            abort(404);
        }
        $this->authorize('admin.frais-dossier.edit', $fraisDossier);


        return  [
            'fraisDossier' => FraisDossier::with(['saison'])->find($fraisDossier->id),
        ];
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateFraisDossier $request
     * @param FraisDossier $fraisDossier
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateFraisDossier $request, FraisDossier $fraisDossier)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        DB::transaction(static function () use ($sanitized, $fraisDossier) {
            $saison = [
                'titre' => trans('admin.frais-dossier.title') . ' ' . parse_date($sanitized['debut'])->format('d-m-Y') . ' - ' . parse_date($sanitized['fin'])->format('d-m-Y'),
                'debut' => $sanitized['debut'],
                'fin' => $sanitized['fin'],
                'model_saison' => 'frais_dossier'
            ];
            $saison = Saison::find($fraisDossier->saison_id)
                ->update($saison);
            // Update changed values FraisDossier
            $fraisDossier->update(['prix' => $sanitized['prix']]);
        });

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/frais-dossiers'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/frais-dossiers');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroyFraisDossier $request
     * @param FraisDossier $fraisDossier
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroyFraisDossier $request, FraisDossier $fraisDossier)
    {
        $fraisDossier->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroyFraisDossier $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroyFraisDossier $request): Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    FraisDossier::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
