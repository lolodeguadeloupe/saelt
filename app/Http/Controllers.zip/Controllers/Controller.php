<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Front\GestionCommandeUtilisateurController;
use App\Models\Ile;
use App\Models\ServicePort;
use App\Models\TypePersonne;
use App\Models\Ville;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{

    use AuthorizesRequests,
        DispatchesJobs,
        ValidatesRequests;

    protected $request;
    protected $typeSupplement;

    public function __construct(\Illuminate\Http\Request $request)
    {
        $this->request = $request;
        $this->typeSupplement = collect([
            ['id' => 1, 'value' => 'dejeneur','icon'=>'assets/img/supplement/repas.png'],
            ['id' => 2, 'value' => 'activite','icon'=>'assets/img/supplement/activity.png'],
            ['id' => 3, 'value' => 'autres','icon'=>'assets/img/supplement/autre.png']
        ])->map(function ($data) {
            $data = collect($data)->put('label', trans('admin.supplement-excursion.type.' . $data['value']));
            return $data;
        });
    }

    protected function viewCustom($view = null, $data = [], $mergeData = [])
    {
        $commande = GestionCommandeUtilisateurController::all($this->request);
        $count_commande = 0;
        collect($commande)->map(function ($first_item) use (&$count_commande) {
            $count_commande = $count_commande + collect($first_item)->count();
        });
        /* */
        $aside = collect(collect($data)->get('aside', []));
        $aside->put('ile', Ile::all());
        $aside->put('ville',Ville::all());
        $aside->put('personne',TypePersonne::whereNull('model')->whereNull('model_id')->get());
        $aside->put('count_commande', $count_commande);
        /* */
        $data['aside'] = $aside->toJson();
        return view($view, $data, $mergeData);
    }
}
